-- -------------------------------------------
SET AUTOCOMMIT=0;
START TRANSACTION;
SET SQL_QUOTE_SHOW_CREATE = 1;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
-- -------------------------------------------

-- -------------------------------------------

-- START BACKUP

-- -------------------------------------------

-- -------------------------------------------

-- TABLE `tbl_banner`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_banner`;
CREATE TABLE IF NOT EXISTS `tbl_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_file` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_banner_create_user_id` (`create_user_id`),
  CONSTRAINT `fk_banner_create_user_id` FOREIGN KEY (`create_user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_cart`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_cart`;
CREATE TABLE IF NOT EXISTS `tbl_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quantity` int(11) DEFAULT NULL,
  `actual_price` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `discounted_price` varchar(125) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_id` int(11) NOT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cart_created_by_id` (`created_by_id`),
  KEY `fk_cart_company_id` (`company_id`),
  CONSTRAINT `fk_cart_company_id` FOREIGN KEY (`company_id`) REFERENCES `tbl_company` (`id`),
  CONSTRAINT `fk_cart_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_cart_item`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_cart_item`;
CREATE TABLE IF NOT EXISTS `tbl_cart_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `actual_price` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `discounted_price` varchar(125) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cart_item_created_by_id` (`created_by_id`),
  KEY `fk_cart_item_product_id` (`product_id`),
  KEY `fk_cart_item_cart_id` (`cart_id`),
  CONSTRAINT `fk_cart_item_cart_id` FOREIGN KEY (`cart_id`) REFERENCES `tbl_cart` (`id`),
  CONSTRAINT `fk_cart_item_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_cart_item_product_id` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_category`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `image_file` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_category_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_category_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_chat_group`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_chat_group`;
CREATE TABLE IF NOT EXISTS `tbl_chat_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `status` text COLLATE utf8_unicode_ci,
  `logo` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_chat_group_user`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_chat_group_user`;
CREATE TABLE IF NOT EXISTS `tbl_chat_group_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `is_admin` tinyint(2) DEFAULT '0',
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chat_group_user_group_id` (`group_id`),
  CONSTRAINT `fk_chat_group_user_group_id` FOREIGN KEY (`group_id`) REFERENCES `tbl_chat_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_chat_message`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_chat_message`;
CREATE TABLE IF NOT EXISTS `tbl_chat_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `to_user_name` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_use_name` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `to_user_id` int(11) DEFAULT NULL,
  `from_user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_chat_response`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_chat_response`;
CREATE TABLE IF NOT EXISTS `tbl_chat_response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) DEFAULT NULL,
  `type_id` tinyint(2) DEFAULT '0',
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chat_response_message_id` (`message_id`),
  KEY `fk_chat_response_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_chat_response_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_chat_response_message_id` FOREIGN KEY (`message_id`) REFERENCES `tbl_chat_message` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_company`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_company`;
CREATE TABLE IF NOT EXISTS `tbl_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contact_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `known_as` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_number` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `vat_registration_number` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `plan_id` int(11) NOT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_company_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_company_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_company_admin`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_company_admin`;
CREATE TABLE IF NOT EXISTS `tbl_company_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contact_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `salutation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `registration_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address_line1` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `address_line2` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `pincode` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `permission` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `passport_image` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_company_admin_created_by_id` (`created_by_id`),
  KEY `fk_company_admin_user_id` (`user_id`),
  KEY `fk_company_admin_company_id` (`company_id`),
  CONSTRAINT `fk_company_admin_company_id` FOREIGN KEY (`company_id`) REFERENCES `tbl_company` (`id`),
  CONSTRAINT `fk_company_admin_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_company_admin_user_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_company_prescriber`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_company_prescriber`;
CREATE TABLE IF NOT EXISTS `tbl_company_prescriber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contact_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `salutation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `registration_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `company_type` int(11) NOT NULL,
  `address_line1` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `address_line2` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `pincode` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `permission` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `passport_image` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_company_prescriber_created_by_id` (`created_by_id`),
  KEY `fk_company_prescriber_user_id` (`user_id`),
  KEY `fk_company_prescriber_company_id` (`company_id`),
  CONSTRAINT `fk_company_prescriber_company_id` FOREIGN KEY (`company_id`) REFERENCES `tbl_company` (`id`),
  CONSTRAINT `fk_company_prescriber_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_company_prescriber_user_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_coupon`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_coupon`;
CREATE TABLE IF NOT EXISTS `tbl_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `percentage` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_coupon_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_coupon_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_coupon_user`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_coupon_user`;
CREATE TABLE IF NOT EXISTS `tbl_coupon_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_coupon_user_created_by_id` (`created_by_id`),
  KEY `fk_coupon_user_coupon_id` (`coupon_id`),
  KEY `fk_coupon_user_user_id` (`user_id`),
  CONSTRAINT `fk_coupon_user_coupon_id` FOREIGN KEY (`coupon_id`) REFERENCES `tbl_coupon` (`id`),
  CONSTRAINT `fk_coupon_user_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_coupon_user_user_id` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_deal`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_deal`;
CREATE TABLE IF NOT EXISTS `tbl_deal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_deal_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_deal_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_delivery_address`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_delivery_address`;
CREATE TABLE IF NOT EXISTS `tbl_delivery_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `address_line1` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `address_line2` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `pincode` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `company_id` int(11) NOT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_delivery_address_created_by_id` (`created_by_id`),
  KEY `fk_delivery_address_company_id` (`company_id`),
  CONSTRAINT `fk_delivery_address_company_id` FOREIGN KEY (`company_id`) REFERENCES `tbl_company` (`id`),
  CONSTRAINT `fk_delivery_address_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_email_queue`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_email_queue`;
CREATE TABLE IF NOT EXISTS `tbl_email_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_published` datetime DEFAULT NULL,
  `last_attempt` datetime DEFAULT NULL,
  `date_sent` datetime DEFAULT NULL,
  `attempts` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `model_type` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_account_id` int(11) DEFAULT NULL,
  `message_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_feed_activity`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_feed_activity`;
CREATE TABLE IF NOT EXISTS `tbl_feed_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_id` int(11) NOT NULL,
  `icon` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_type` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_feed_activity_create_user_id` (`created_by_id`),
  CONSTRAINT `fk_feed_activity_create_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_invoice_address`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_invoice_address`;
CREATE TABLE IF NOT EXISTS `tbl_invoice_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address_line1` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `address_line2` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `pincode` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `company_id` int(11) NOT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_invoice_address_created_by_id` (`created_by_id`),
  KEY `fk_invoice_address_company_id` (`company_id`),
  CONSTRAINT `fk_invoice_address_company_id` FOREIGN KEY (`company_id`) REFERENCES `tbl_company` (`id`),
  CONSTRAINT `fk_invoice_address_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_log`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_log`;
CREATE TABLE IF NOT EXISTS `tbl_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `error` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `api` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `state_id` int(11) DEFAULT '1',
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_login_history`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_login_history`;
CREATE TABLE IF NOT EXISTS `tbl_login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `failer_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_media_file`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_media_file`;
CREATE TABLE IF NOT EXISTS `tbl_media_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `thumb_file` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `extension` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) DEFAULT NULL,
  `model_type` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  `createBy` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comment_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_comment_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_notice`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_notice`;
CREATE TABLE IF NOT EXISTS `tbl_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `model_type` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notice_created_by` (`created_by_id`),
  CONSTRAINT `fk_notice_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_notification`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_notification`;
CREATE TABLE IF NOT EXISTS `tbl_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `is_read` tinyint(2) DEFAULT '0',
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `to_user_id` int(11) DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_order`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_order`;
CREATE TABLE IF NOT EXISTS `tbl_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quantity` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `price` varchar(125) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delivery_status` int(11) DEFAULT '1',
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_created_by_id` (`created_by_id`),
  KEY `fk_order_company_id` (`company_id`),
  CONSTRAINT `fk_order_company_id` FOREIGN KEY (`company_id`) REFERENCES `tbl_company` (`id`),
  CONSTRAINT `fk_order_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_order_item`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_order_item`;
CREATE TABLE IF NOT EXISTS `tbl_order_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quantity` int(11) NOT NULL,
  `price` varchar(125) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `delivery_status` int(11) DEFAULT '1',
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_item_created_by_id` (`created_by_id`),
  KEY `fk_order_item_product_id` (`product_id`),
  KEY `fk_order_item_order_id` (`order_id`),
  CONSTRAINT `fk_order_item_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_order_item_order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`id`),
  CONSTRAINT `fk_order_item_product_id` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_page`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_page`;
CREATE TABLE IF NOT EXISTS `tbl_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_page_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_page_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_plan_type`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_plan_type`;
CREATE TABLE IF NOT EXISTS `tbl_plan_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `percent` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `type_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) DEFAULT '0',
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_product`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_product`;
CREATE TABLE IF NOT EXISTS `tbl_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `code` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `actual_quantity` varchar(125) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `deal_id` int(11) DEFAULT NULL,
  `is_fav` tinyint(2) DEFAULT '0',
  `state_id` tinyint(2) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_product_created_by_id` (`created_by_id`),
  KEY `fk_product_deal_id` (`deal_id`),
  KEY `fk_product_category_id` (`category_id`),
  CONSTRAINT `fk_product_category_id` FOREIGN KEY (`category_id`) REFERENCES `tbl_category` (`id`),
  CONSTRAINT `fk_product_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_product_deal_id` FOREIGN KEY (`deal_id`) REFERENCES `tbl_deal` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_setting`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_setting`;
CREATE TABLE IF NOT EXISTS `tbl_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `type_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) DEFAULT '0',
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_shadow`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_shadow`;
CREATE TABLE IF NOT EXISTS `tbl_shadow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to_id` int(11) NOT NULL,
  `state_id` int(11) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_user`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` int(11) DEFAULT '0',
  `about_me` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT '0',
  `profile_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tos` int(11) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT '0',
  `last_visit_time` datetime DEFAULT NULL,
  `last_action_time` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `login_error_count` int(11) DEFAULT NULL,
  `activation_key` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `access_token` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_wishlist`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_wishlist`;
CREATE TABLE IF NOT EXISTS `tbl_wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `price` varchar(125) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) DEFAULT '1',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_wishlist_created_by_id` (`created_by_id`),
  KEY `fk_wishlist_company_id` (`company_id`),
  CONSTRAINT `fk_wishlist_company_id` FOREIGN KEY (`company_id`) REFERENCES `tbl_company` (`id`),
  CONSTRAINT `fk_wishlist_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




INSERT INTO `tbl_banner` (`id`,`image_file`,`title`,`description`,`state_id`,`type_id`,`created_on`,`updated_on`,`create_user_id`) VALUES
("1","banner-1533279166banner_1.jpg","The All New Professional-C Portfolio","<p>Aliquet dignissim orci dignissim vehicula phasellus Erat etiam posuere felis donec augue dapibus. Congue tempus pede .</p>","1","0","2018-08-03 12:20:39","2018-08-03 12:25:12","1"),
("2","banner-1533279074banner_1.jpg","Products from world leading suppliers.","<p>Aliquet dignissim orci dignissim vehicula phasellus Erat etiam posuere felis donec augue dapibus. Congue tempus pede .</p>","1","0","2018-08-03 12:21:14","2018-08-03 12:25:00","1"),
("3","banner-1533279104banner_1.jpg","Buy ANY 5 get 5% off Buy 10 get 10% off.","<p>Aliquet dignissim orci dignissim vehicula phasellus Erat etiam posuere felis donec augue dapibus. Congue tempus pede .</p>","1","0","2018-08-03 12:21:44","2018-08-03 12:24:47","1"),
("4","banner-1533279143banner_1.jpg","The All New Professional-C Portfolio","<p>Aliquet dignissim orci dignissim vehicula phasellus Erat etiam posuere felis donec augue dapibus. Congue tempus pede .</p>","1","0","2018-08-03 12:22:23","2018-08-09 17:53:01","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_cart` (`id`,`quantity`,`actual_price`,`discounted_price`,`company_id`,`state_id`,`type_id`,`created_on`,`created_by_id`) VALUES
("3","","0.32","0.288","8","1","0","2018-08-09 20:19:56","13"),
("4","","434.62","391.158","9","1","0","2018-08-10 10:17:01","14");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_cart_item` (`id`,`cart_id`,`product_id`,`actual_price`,`discounted_price`,`quantity`,`state_id`,`type_id`,`created_on`,`created_by_id`) VALUES
("34","4","4","0.16","0.144","1","1","0","2018-08-10 10:51:29","14"),
("35","4","5","110.5","99.45","1","1","0","2018-08-10 10:51:29","14"),
("36","4","6","0","0","2","1","0","2018-08-10 10:51:29","14"),
("37","4","7","0.8","0.72","2","1","0","2018-08-10 10:51:29","14"),
("38","4","8","69.53","62.577","2","1","0","2018-08-10 10:51:29","14"),
("39","4","9","1","0.9","2","1","0","2018-08-10 10:51:29","14"),
("40","4","10","69.53","62.577","2","1","0","2018-08-10 10:51:29","14"),
("41","4","11","4.05","3.645","2","1","0","2018-08-10 10:51:29","14"),
("42","4","12","7.68","6.912","2","1","0","2018-08-10 10:51:29","14"),
("43","4","13","0.14","0.126","2","1","0","2018-08-10 10:51:29","14"),
("44","4","14","0.25","0.225","2","1","0","2018-08-10 10:51:29","14"),
("45","4","15","9","8.1","2","1","0","2018-08-10 10:51:29","14"),
("46","3","4","0.16","0.144","2","1","0","2018-08-10 10:59:36","13");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_category` (`id`,`title`,`description`,`image_file`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","POM","POM description","default.png","1","0","2018-08-03 11:14:33","2018-08-07 12:45:42","1"),
("2","GSL","GSL description ","about.jpg","1","0","2018-08-03 11:15:10","2018-08-09 17:52:24","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_company` (`id`,`first_name`,`last_name`,`email`,`contact_no`,`company_name`,`known_as`,`registration_number`,`vat_registration_number`,`country`,`plan_id`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("8","Carlos","West","Company@test.in","96576746","Company","","764754","435","1","5","1","0","2018-08-09 19:34:34","2018-08-09 19:42:57","13"),
("9","christina","rebu","chris@gmail.com","4534","fddfsd","dfsd","f2342342","23423","1","5","1","0","2018-08-09 20:09:01","2018-08-10 10:03:06","14");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_company_admin` (`id`,`company_id`,`first_name`,`last_name`,`email`,`contact_no`,`salutation`,`registration_number`,`address_line1`,`address_line2`,`city`,`country`,`pincode`,`permission`,`passport_image`,`state_id`,`type_id`,`created_on`,`updated_on`,`user_id`,`created_by_id`) VALUES
("7","8","Cortez","Kassulke","Company@test.in","","1","5435345","Mohali","","","","","[\"0\",\"2\"]","","1","0","","","13","13"),
("8","9","dvffsg","admin","chris@gmail.com","","0","","Mohali","","Mohali","","160071","[\"0\",\"1\",\"2\",\"3\"]","","1","0","","","14","14");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_delivery_address` (`id`,`name`,`email`,`phone`,`address_line1`,`address_line2`,`city`,`country`,`pincode`,`company_id`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("4","Obie Schimmel","Company@test.in","85674564564","Mohali","","Mohali","1","234234","8","1","0","2018-08-09 19:34:34","2018-08-09 19:34:34","13"),
("5","contact name","chris@gmail.com","5345435","Mohali","","Mohali","0","160071","9","1","0","2018-08-09 20:09:01","2018-08-09 20:09:01","14");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_email_queue` (`id`,`from_email`,`to_email`,`message`,`subject`,`date_published`,`last_attempt`,`date_sent`,`attempts`,`state_id`,`model_id`,`model_type`,`email_account_id`,`message_id`) VALUES
("1","admin@toxsl.in","admincompany@toxsl.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			You have been ActiveFrom Confidence Pharmacysite</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			</br> </br>
			</br> </br>
			</br> </br>
		</p>

		<p></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","You have been Active Confidence Pharmacy","","","2018-08-09 15:03:33","","1","","","","d8793d7ed35d86fe4c5010849de8d82d@jupiter.toxsl.in"),
("2","admin@toxsl.in","chris@toxsl.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			You have been ActiveFrom Confidence Pharmacysite</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			</br> </br>
			</br> </br>
			</br> </br>
		</p>

		<p></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","You have been Active Confidence Pharmacy","","","2018-08-09 15:04:49","","1","","","","59f2937463567482b33ad48a407a27b7@jupiter.toxsl.in"),
("3","admin@toxsl.in","admincompany@toxsl.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			You have been BannedFrom Confidence Pharmacysite</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			</br> </br>
			</br> </br>
			</br> </br>
		</p>

		<p></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","You have been Banned Confidence Pharmacy","","","2018-08-09 16:29:59","","1","","","","3fcc6b194a78722e21c51116d9c2cfab@jupiter.toxsl.in"),
("4","admin@toxsl.in","admincompany@toxsl.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			You have been ActiveFrom Confidence Pharmacysite</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			</br> </br>
			</br> </br>
			</br> </br>
		</p>

		<p></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","You have been Active Confidence Pharmacy","","","2018-08-09 16:30:16","","1","","","","e316b8c6035e362169e046084c6a9481@jupiter.toxsl.in"),
("5","admin@toxsl.in","sdfsd@egfh.dgfdgd","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			account has been successfully created. You can login to your account
			using the link given belowssss :</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			Your Details :- </br> </br>
			Username:sdfsd@egfh.dgfdgd</br> </br>
			Password:admin123</br> </br>
		</p>

		<p><a href=\"http://jupiter.toxsl.in/confidence-pharmacy-web/user/login\">http://jupiter.toxsl.in/confidence-pharmacy-web/user/login</a></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New Account Created Confidence Pharmacy","","","2018-08-09 18:32:28","","1","","","","acf88596365f5ad83866f66f82611c15@jupiter.toxsl.in"),
("6","admin@toxsl.in","admincompany@toxsl.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			You have been ActiveFrom Confidence Pharmacysite</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			</br> </br>
			</br> </br>
			</br> </br>
		</p>

		<p></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","You have been Active Confidence Pharmacy","","","2018-08-09 19:11:02","","1","","","","7a07eae9461a3ba565f516aafde63b11@jupiter.toxsl.in"),
("7","admin@toxsl.in","Company@test.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			account has been successfully created. You can login to your account
			using the link given belowssss :</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			Your Details :- </br> </br>
			Username:Company@test.in</br> </br>
			Password:admin123</br> </br>
		</p>

		<p><a href=\"http://jupiter.toxsl.in/confidence-pharmacy-web/user/login\">http://jupiter.toxsl.in/confidence-pharmacy-web/user/login</a></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New Account Created Confidence Pharmacy","","","2018-08-09 19:34:35","","1","","","","33ae1af023e3c903112a22b84fc3f6a9@jupiter.toxsl.in"),
("8","admin@toxsl.in","Company@test.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			You have been ActiveFrom Confidence Pharmacysite</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			</br> </br>
			</br> </br>
			</br> </br>
		</p>

		<p></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","You have been Active Confidence Pharmacy","","","2018-08-09 19:39:23","","1","","","","ef4ba472c68d8779d090a55f8d5866cc@jupiter.toxsl.in"),
("9","admin@toxsl.in","Company@test.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			You have been ActiveFrom Confidence Pharmacysite</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			</br> </br>
			</br> </br>
			</br> </br>
		</p>

		<p></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","You have been Active Confidence Pharmacy","","","2018-08-09 19:42:13","","1","","","","bb26a48775bdf33b6c54588d3ff9019f@jupiter.toxsl.in"),
("10","admin@toxsl.in","chris@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			account has been successfully created. You can login to your account
			using the link given belowssss :</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			Your Details :- </br> </br>
			Username:chris@gmail.com</br> </br>
			Password:admin@123</br> </br>
		</p>

		<p><a href=\"http://jupiter.toxsl.in/confidence-pharmacy-web/user/login\">http://jupiter.toxsl.in/confidence-pharmacy-web/user/login</a></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","New Account Created Confidence Pharmacy","","","2018-08-09 20:09:02","","1","","","","7e272a6c929297db59ead5033190a604@jupiter.toxsl.in"),
("11","admin@toxsl.in","chris@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			You have been ActiveFrom Confidence Pharmacysite</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			</br> </br>
			</br> </br>
			</br> </br>
		</p>

		<p></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","You have been Active Confidence Pharmacy","","","2018-08-10 10:02:37","","1","","","","6e355126ddef797dbcd95f63473f9abe@jupiter.toxsl.in"),
("12","admin@toxsl.in","chris@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			You have been InactiveFrom Confidence Pharmacysite</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			</br> </br>
			</br> </br>
			</br> </br>
		</p>

		<p></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","You have been Inactive Confidence Pharmacy","","","2018-08-10 10:02:53","","1","","","","bb874b3c696318a8d1cecef312e8e071@jupiter.toxsl.in"),
("13","admin@toxsl.in","chris@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\">Confidence Pharmacy</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">Hi ,</h3></td>
</tr>

<tr>

	<td align=\"left\">
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">Your
			You have been ActiveFrom Confidence Pharmacysite</p>
		<p
			style=\"font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;\">
			</br> </br>
			</br> </br>
			</br> </br>
		</p>

		<p></p>

	</td>
</tr>

</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br>Confidence Pharmacy Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy; Confidence Pharmacy</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","You have been Active Confidence Pharmacy","","","2018-08-10 10:04:24","","1","","","","2c97b96a0c683f43ad0fda34971a956b@jupiter.toxsl.in");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_invoice_address` (`id`,`address_line1`,`address_line2`,`city`,`country`,`pincode`,`company_id`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("4","Mohali","","Mohali","1","160065","8","1","0","2018-08-09 19:34:34","2018-08-09 19:34:47","13"),
("5","Mohali","","Mohali","2","160071","9","1","0","2018-08-09 20:09:01","2018-08-09 20:09:01","14");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_log` (`id`,`error`,`api`,`description`,`state_id`,`link`,`type_id`,`created_on`) VALUES
("1","Missing required parameters: filename","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘thumbnail‘, Array)
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘category/thumbn...‘, Array)
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /confidence-pharmacy-web/category/thumbnail","0","2018-08-09 15:34:00"),
("2","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘backend‘, Array)
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/backend‘, Array)
#10 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /confidence-pharmacy-web/user/backend","0","2018-08-09 16:28:14"),
("3","Method Not Allowed. This URL can only handle the following request methods: POST.","","#0 [internal function]: yii\\filters\\VerbFilter->beforeAction(Object(yii\\base\\ActionEvent))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘delete‘, Array)
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘product/delete‘, Array)
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#10 {main}","1","405:  /confidence-pharmacy-web/product/delete/3/shirt","0","2018-08-09 17:50:59"),
("4","You are not allowed to access this page.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/controllers/NoticeController.php(97): app\\controllers\\NoticeController->findModel(‘3‘)
#1 [internal function]: app\\controllers\\NoticeController->actionView(‘3‘, ‘dasd‘)
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/InlineAction.php(67): call_user_func_array(Array, Array)
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘view‘, Array)
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘notice/view‘, Array)
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#8 {main}","1","403:  /confidence-pharmacy-web/notice/3/dasd","0","2018-08-09 17:55:46"),
("5","Method Not Allowed. This URL can only handle the following request methods: POST.","","#0 [internal function]: yii\\filters\\VerbFilter->beforeAction(Object(yii\\base\\ActionEvent))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘delete‘, Array)
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘company/delete‘, Array)
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#10 {main}","1","405:  /confidence-pharmacy-web/company/delete/7/dvd","0","2018-08-09 18:34:03"),
("6","Method Not Allowed. This URL can only handle the following request methods: POST.","","#0 [internal function]: yii\\filters\\VerbFilter->beforeAction(Object(yii\\base\\ActionEvent))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘delete‘, Array)
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘company/delete‘, Array)
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#10 {main}","1","405:  /confidence-pharmacy-web/company/delete/7/dvd","0","2018-08-09 18:36:19"),
("7","Method Not Allowed. This URL can only handle the following request methods: POST.","","#0 [internal function]: yii\\filters\\VerbFilter->beforeAction(Object(yii\\base\\ActionEvent))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘delete‘, Array)
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘company/delete‘, Array)
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#10 {main}","1","405:  /confidence-pharmacy-web/company/delete/7/dvd","0","2018-08-09 18:38:00"),
("8","Method Not Allowed. This URL can only handle the following request methods: POST.","","#0 [internal function]: yii\\filters\\VerbFilter->beforeAction(Object(yii\\base\\ActionEvent))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘delete‘, Array)
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/delete‘, Array)
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#10 {main}","1","405:  /confidence-pharmacy-web/user/delete/12/fdsfsd-dfsfs","0","2018-08-09 18:38:26"),
("9","Method Not Allowed. This URL can only handle the following request methods: POST.","","#0 [internal function]: yii\\filters\\VerbFilter->beforeAction(Object(yii\\base\\ActionEvent))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘delete‘, Array)
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/delete‘, Array)
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#10 {main}","1","405:  /confidence-pharmacy-web/user/delete/10/admin-admin","0","2018-08-09 19:46:23"),
("10","Method Not Allowed. This URL can only handle the following request methods: POST.","","#0 [internal function]: yii\\filters\\VerbFilter->beforeAction(Object(yii\\base\\ActionEvent))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘delete‘, Array)
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/delete‘, Array)
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#10 {main}","1","405:  /confidence-pharmacy-web/user/delete/10/admin-admin","0","2018-08-09 19:47:44"),
("11","Method Not Allowed. This URL can only handle the following request methods: POST.","","#0 [internal function]: yii\\filters\\VerbFilter->beforeAction(Object(yii\\base\\ActionEvent))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘delete‘, Array)
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/delete‘, Array)
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#10 {main}","1","405:  /confidence-pharmacy-web/user/delete/10/admin-admin","0","2018-08-09 19:48:42"),
("12","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘view‘, Array)
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘company/view‘, Array)
#10 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /confidence-pharmacy-web/company/8/company","0","2018-08-09 20:10:15"),
("13","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/index‘, Array)
#10 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /confidence-pharmacy-web/user/index","0","2018-08-09 20:16:39"),
("14","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘add‘, Array)
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/add‘, Array)
#10 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /confidence-pharmacy-web/user/add","0","2018-08-10 10:38:46"),
("15","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/index‘, Array)
#10 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /confidence-pharmacy-web/user/index","0","2018-08-10 10:46:50"),
("16","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/index‘, Array)
#10 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /confidence-pharmacy-web/user/index","0","2018-08-10 10:58:16"),
("17","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘page/index‘, Array)
#10 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /confidence-pharmacy-web/page/index","0","2018-08-10 10:58:22"),
("18","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘login-history/i...‘, Array)
#10 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /confidence-pharmacy-web/login-history/index","0","2018-08-10 10:58:27"),
("19","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/index‘, Array)
#10 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /confidence-pharmacy-web/user/index","0","2018-08-10 10:58:36"),
("20","Missing required parameters: id","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘image‘, Array)
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘media/file/imag...‘, Array)
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /confidence-pharmacy-web/media/file/image","0","2018-08-10 11:03:06"),
("21","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/protected/components/TController.php(247): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘update‘, Array)
#9 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/update‘, Array)
#10 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/toxsl/public_html/jupiter_toxsl_in/confidence-pharmacy-web/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /confidence-pharmacy-web/user/update/13","0","2018-08-10 11:06:40");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("1","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 14:24:31"),
("2","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 14:29:28"),
("3","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 14:29:29"),
("4","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 14:29:33"),
("5","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 14:38:34"),
("6","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 15:16:44"),
("7","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 17:23:20"),
("8","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 17:58:30"),
("9","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 18:00:48"),
("10","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 18:01:12"),
("11","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 18:01:19"),
("12","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 18:01:25"),
("13","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 18:27:01"),
("14","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 19:14:05"),
("15","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 19:32:09"),
("16","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 19:35:56"),
("17","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 19:36:12"),
("18","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 19:38:17"),
("19","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-09 19:39:11"),
("20","13","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 19:42:28"),
("21","13","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 19:42:40"),
("22","13","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 19:42:49"),
("23","13","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 19:43:03"),
("24","11","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 19:44:06"),
("25","11","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 19:44:12"),
("26","13","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 20:02:22"),
("27","13","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 20:02:27"),
("28","13","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 20:05:31"),
("29","13","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 20:05:38"),
("30","14","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 20:09:17"),
("31","14","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 20:10:15"),
("32","14","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-09 20:12:25"),
("33","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-10 09:34:56"),
("34","14","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-10 10:00:57"),
("35","14","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/login","2018-08-10 10:01:09"),
("36","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-10 10:04:15"),
("37","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-10 10:34:27"),
("38","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-10 11:16:59"),
("39","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://jupiter.toxsl.in/confidence-pharmacy-web/user/backend","2018-08-10 11:17:06");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_media_file` (`id`,`title`,`file`,`thumb_file`,`size`,`extension`,`model_id`,`model_type`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`,`createBy`) VALUES
("4","error.png","file-1533876335.png","thumb_200*200-1533876335.png","4310","png","16","app\\models\\Product","0","0","2018-08-10 10:15:35","2018-08-10 10:15:35","1","admin");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_plan_type` (`id`,`title`,`percent`,`type_id`,`state_id`,`created_by_id`) VALUES
("5","Basic","10","10","1","1"),
("6","Platinum","100","","1","1"),
("7","Gold","20","","1","1"),
("10","Silver","12","","1","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_product` (`id`,`title`,`description`,`code`,`price`,`actual_quantity`,`category_id`,`class_id`,`deal_id`,`is_fav`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("4","Aciclovir 200mg Tablets (POM)  ( each)","","ACI200AAH01","0.16","1005362","1","0","","0","1","0","2018-08-03 11:20:14","2018-08-03 11:20:14","1"),
("5","Fibrovein 0.2% 10x5ml vials (POM)","","FIB002STD01","110.5","1098756","1","0","","0","1","0","2018-08-03 11:21:00","2018-08-03 11:21:00","1"),
("6","10% DISCOUNT APPLIED ON ALL PRODUCTS","","OFFER 10%","0","9999900976","2","0","","0","1","0","2018-08-03 11:21:35","2018-08-03 11:21:35","1"),
("7","3Way Luer lok  Connecta  ref 394601 (1)","","CON01BDL01","0.8","99989","2","0","","0","1","0","2018-08-03 11:22:08","2018-08-03 11:22:08","1"),
("8","Access Port Needles 20g x 51mm ref B-20302-10 [pack of 10]","","ACC051ALL01","69.53","999999996","2","0","","0","1","0","2018-08-03 11:22:43","2018-08-03 11:22:43","1"),
("9","Acetone 50ml bottle","","ACE050AAH01","1","1009733","2","0","","0","1","0","2018-08-03 11:23:54","2018-08-03 11:23:54","1"),
("10","Access Port Needles 20g x 89mm ref B-20301-10 [pack of 10]","","ACC089AAL01","69.53","999999997","2","0","","0","1","0","2018-08-03 11:24:43","2018-08-03 11:24:43","1"),
("11","Aciclovir 200mg tablets 1x25 (POM)","","ACI200AAH02","4.05","100098486","1","0","","0","1","0","2018-08-03 11:25:43","2018-08-03 11:25:43","1"),
("12","Aciclovir 400 mg tablets (56) (POM)","","ACI400AAH56","7.68","109999495","1","0","","0","1","0","2018-08-03 11:26:20","2018-08-03 11:26:20","1"),
("13","Aciclovir 400mg tablets (POM)[each]","","ACI400AAH01","0.14","1007560","1","0","","0","1","0","2018-08-03 11:27:02","2018-08-03 11:27:02","1"),
("14","Aciclovir 800 mg tablets (POM) EACH","","ACI800AAH01","0.25","999998905","1","0","","0","1","0","2018-08-03 11:27:44","2018-08-03 11:27:44","1"),
("15","Aciclovir 800mg tablet POM (35)","","ACI800AAH35","9.0","1000000848","1","0","","0","1","0","2018-08-03 11:28:21","2018-08-03 11:28:21","1"),
("16","Aciclovir Cream 5% w/w 2g (POM)","","ACI0052GAAH01","1.53","999763","1","0","","0","1","0","2018-08-03 11:28:54","2018-08-03 11:28:54","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_setting` (`id`,`key`,`title`,`value`,`type_id`,`state_id`,`created_by_id`) VALUES
("1","appConfig","App Configration","{\"companyUrl\":{\"value\":\"https://www.toxsl.com\",\"type\":\"0\",\"required\":\"1\"},\"company\":{\"value\":\"ToXSL Technologies\",\"type\":\"0\",\"required\":\"1\"},\"companyEmail\":{\"value\":\"admin@toxsl.in\",\"type\":\"0\",\"required\":\"1\"},\"companyContactEmail\":{\"value\":\"admin@toxsl.in\",\"type\":\"0\",\"required\":\"\"},\"companyContactNo\":{\"value\":\"9569127788\",\"type\":\"0\",\"required\":\"\"},\"companyAddress\":{\"value\":\"C-127, 4th floor, Phase 8, Industrial Area, Sector 72, Mohali, Punjab\",\"type\":\"0\",\"required\":\"\"},\"loginCount\":{\"value\":\"-6\",\"type\":\"2\",\"required\":\"\"}}","","0","1"),
("2","smtp","SMTP Configration","{\"host\":{\"type\":0,\"value\":\"\",\"required\":true},\"username\":{\"type\":0,\"value\":\"\",\"required\":true},\"password\":{\"type\":0,\"value\":\"\",\"required\":true},\"port\":{\"type\":0,\"value\":\"\",\"required\":true},\"encryption\":{\"type\":0,\"value\":\"\",\"required\":false}}","","0","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_shadow` (`id`,`to_id`,`state_id`,`created_on`,`created_by_id`) VALUES
("22","13","1","","1"),
("32","13","1","","1"),
("38","13","1","","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_user` (`id`,`full_name`,`first_name`,`last_name`,`username`,`email`,`password`,`date_of_birth`,`gender`,`about_me`,`contact_no`,`address`,`latitude`,`longitude`,`city`,`country`,`zipcode`,`language`,`email_verified`,`profile_file`,`tos`,`role_id`,`state_id`,`type_id`,`last_visit_time`,`last_action_time`,`last_password_change`,`login_error_count`,`activation_key`,`access_token`,`timezone`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","admin","admin","","","admin@toxsl.in","$2y$13$Vw0IilWCMA5Acfts6NYoR.wNLb6uxrBIk.moeDs3wh1zJBJ/FRU.q","","0","","5345435","","","","","","","","0","user-1533819899-profile_file.jpg","","0","1","0","2018-08-03 11:07:51","","","","MEyVJ5hMeYcFEhBvhfVGB81d3MLx9ge-_1533274671","Mdt4O3N-BhxP1W4O0FZKRb0T08EPbYuT","","2018-08-03 11:07:50","2018-08-09 18:34:59",""),
("11","","chris","chris","chris","chris@toxsl.com","$2y$13$kWu5wKqG5wGCTvetNMUacOrtzZagfwQXCzwruj1/FExP98GCY2lEO","","0","","976856756","","","","","","","","0","user-1533819891-profile_file.jpg","1","5","1","0","","","","","sp4n74m-NJHoeEwar58BLA71NMR3AQ79_1533804852","YUlXPRrS5a3AX__cIp2hBZ14fvL1KN8m","","2018-08-09 14:24:12","2018-08-09 18:34:51","10"),
("13","","Cortez","Kassulke","Company@test.in","Company@test.in","$2y$13$ZnR8J2Oil1khkjvAuJEPj.CSj21bTQXkDaMRvn9LGu9dPC622BPBq","","0","","","","","","","","","","0","","1","3","1","0","","","","","bhURDAYqqrpNb4hFoTHarBiouwOk-gRh_1533823487","62patm08oABaC_As8L3hw8NeDu9LAQb_","","2018-08-09 19:34:34","2018-08-09 19:42:13","1"),
("14","","dvffsg","admin","chris@gmail.com","chris@gmail.com","$2y$13$IK6Q.HzbeR/PfDS8wTPfk.7AdnajgNEXciUgxrSoySWRmfpP4fzOa","","0","","","","","","","","","","0","","1","3","1","0","2018-08-10 10:01:09","","","","r6BNmJcoFgdi9TNGu0Xf8vVDEA7coZ0h_1533825542","ctGqpxDI0tpKbFUj_1njCxl1HSvTiVsE","","2018-08-09 20:09:01","2018-08-10 10:04:24","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_wishlist` (`id`,`product_id`,`company_id`,`price`,`state_id`,`type_id`,`created_on`,`created_by_id`) VALUES
("1","4","9","0.16","1","0","2018-08-10 10:52:15","14");

 -- -------AutobackUpStarttoxsl------ -- -------------------------------------------
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
COMMIT;
 -- -------AutobackUpStarttoxsl------ -- -------------------------------------------

-- -------------------------------------------

-- END BACKUP

-- -------------------------------------------
